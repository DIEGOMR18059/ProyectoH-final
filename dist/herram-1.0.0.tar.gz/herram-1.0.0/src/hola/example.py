import __init__ as pr

pr.inicializar()
m=pr.Matrix(2,3)
m.multiplicate_scalar(5)